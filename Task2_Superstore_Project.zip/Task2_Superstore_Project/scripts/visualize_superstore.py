import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('data/superstore_synthetic.csv', parse_dates=['Order Date'])
sales_by_cat = df.groupby('Category')['Sales'].sum().sort_values(ascending=False)
sales_by_cat.plot(kind='bar', title='Total Sales by Category')
plt.show()
