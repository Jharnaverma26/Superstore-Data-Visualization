# Task 2 - Superstore Data Visualization Project

This project contains synthetic Superstore data, visualization scripts, and a PDF report demonstrating storytelling with charts.

See /data, /images, /scripts, and the PDF report.